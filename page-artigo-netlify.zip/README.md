# Landing page — Page Assessoria

Landing page estática de produção para `https://artigo.pageassessoria.com/`. O pacote não depende de framework, banco de dados ou processo de build.

## Conteúdo do pacote

- `index.html`: conteúdo, SEO, dados estruturados e configuração de rastreamento.
- `styles.css`: layout responsivo e identidade visual.
- `script.js`: menu, animações, consentimento e eventos de conversão.
- `assets/`: ilustrações SVG, favicon e imagem social.
- `robots.txt` e `sitemap.xml`: indexação.
- `netlify.toml`: publicação, cabeçalhos de segurança e cache.

## Antes do deploy

1. Revise os textos e confirme as afirmações de experiência (5+ anos no serviço e 10+ anos de atuação geral).
2. Se houver um arquivo oficial do logotipo, substitua o wordmark textual no cabeçalho e no rodapé. Preserve um texto alternativo descritivo.
3. Exporte `assets/og-page-artigo.svg` para `assets/og-page-artigo.png` em 1200 × 630 px. O pacote entregue já inclui esse PNG pronto.
4. Confirme o texto inicial do WhatsApp em todos os links `wa.me`.
5. Adicione o ID do GA4 somente se a propriedade já estiver criada (instruções abaixo).

## Deploy no Netlify

### Opção simples: upload manual

1. Entre no Netlify e selecione **Add new project > Deploy manually** (o nome pode variar ligeiramente conforme o idioma da conta).
2. Descompacte o ZIP.
3. Arraste a pasta `page-artigo-netlify` — a pasta que contém `index.html` — para a área de upload.
4. Aguarde a publicação e anote o endereço temporário, por exemplo `nome-do-projeto.netlify.app`.
5. Em **Project configuration > General > Project details**, altere o nome do projeto se desejar. Esse nome define o endereço `*.netlify.app`.

### Opção recomendada para atualizações: Git

Crie um repositório com o conteúdo desta pasta e, no Netlify, selecione **Add new project > Import an existing project**. Como o site é estático:

- Build command: deixe em branco.
- Publish directory: `.` (ponto), se os arquivos estiverem na raiz do repositório.

O arquivo `netlify.toml` já contém essa configuração.

## Criar `artigo.pageassessoria.com` mantendo o DNS no Wix

Faça o deploy antes de alterar o DNS.

### 1. Adicionar o domínio ao Netlify

1. Abra o projeto no Netlify.
2. Vá a **Domain management > Production domains**.
3. Escolha **Add a domain** e depois **Add a domain you already own**.
4. Informe `artigo.pageassessoria.com`.
5. Escolha usar provedor DNS externo. Não transfira os nameservers do domínio principal para o Netlify.
6. O Netlify mostrará o destino CNAME recomendado, normalmente `nome-do-projeto.netlify.app`. Use exatamente o valor exibido no painel.

Documentação oficial: https://docs.netlify.com/manage/domains/configure-domains/configure-external-dns/

### 2. Criar o CNAME no Wix

1. No Wix, abra **Domains** e selecione `pageassessoria.com`.
2. Abra **Advanced > Manage DNS Records** (os rótulos podem variar conforme o idioma).
3. Na seção CNAME, escolha **Add Record**.
4. Preencha:
   - Host name / Nome: `artigo`
   - Value / Aponta para: `nome-do-projeto.netlify.app` (sem `https://` e sem barra final)
   - TTL: mantenha o padrão do Wix.
5. Salve.

Importante: se o domínio estiver apenas conectado ao Wix por apontamento ou usar nameservers de outro provedor, o registro deve ser criado nesse provedor, não no Wix.

Documentação oficial: https://support.wix.com/en/article/managing-dns-records-in-your-wix-account

### 3. Confirmar DNS e HTTPS

1. Volte ao Netlify e abra o aviso **Pending DNS verification** para conferir o registro.
2. Aguarde a propagação. Normalmente ocorre em minutos ou horas, mas pode levar até 24–48 horas.
3. Em **Domain management > HTTPS**, confirme que o certificado TLS foi emitido.
4. Teste `https://artigo.pageassessoria.com/` em uma janela anônima.
5. Não apague registros do domínio principal, de e-mail (MX/TXT) ou do site Wix. Para este projeto, só é necessário adicionar o CNAME `artigo`.

## Rastreamento

O site usa consentimento explícito para scripts de medição. Sem aceite, Meta Pixel e GA4 não são carregados.

### Meta Pixel

O ID `1086986820963849` está configurado no elemento `<html>`:

```html
<html lang="pt-BR" data-meta-pixel-id="1086986820963849" data-ga4-id="">
```

Após o aceite de cookies, o código envia:

- evento padrão `PageView` no carregamento;
- evento personalizado `click_whatsapp` em todos os CTAs do WhatsApp;
- parâmetro `button_location` com a posição do CTA (`header`, `hero`, `content`, `final_cta` ou `mobile_fixed`).

Valide com a extensão Meta Pixel Helper e com **Events Manager > Test events** antes de iniciar a campanha.

### GA4

Crie um fluxo da Web no GA4 e copie o Measurement ID no formato `G-XXXXXXXXXX`. Em `index.html`, preencha somente o valor de `data-ga4-id`:

```html
<html lang="pt-BR" data-meta-pixel-id="1086986820963849" data-ga4-id="G-XXXXXXXXXX">
```

Não cole scripts adicionais do GA4: `script.js` carrega a biblioteca de forma condicional após o consentimento e registra `click_whatsapp`.

## Trocar ou inserir imagens reais

O visual principal fica em `assets/manuscript-flow.svg`. Para usar uma imagem real:

1. Exporte em WebP, preferencialmente entre 1200 e 1600 px de largura.
2. Salve em `assets/`.
3. Troque o `src` da imagem dentro de `.hero-visual` no `index.html`.
4. Atualize `width`, `height` e `alt` para evitar deslocamento de layout e preservar acessibilidade.

Boas imagens para este projeto: detalhe real de manuscrito com marcações, página impressa com gráficos da área de pesquisa ou fotografia editorial do processo de revisão. Evite banco de imagens genérico de pessoas em laboratório.

## Checklist final

- Abrir em celular real e conferir menu, FAQ e CTA fixo.
- Testar todos os links de WhatsApp.
- Aceitar cookies e validar `PageView` e `click_whatsapp`.
- Recusar cookies e confirmar que scripts de medição não são carregados.
- Conferir título, descrição e imagem ao compartilhar a URL.
- Enviar `sitemap.xml` no Google Search Console.
- Vincular a landing page ao aviso de privacidade institucional, se houver exigência jurídica específica.
