(() => {
  'use strict';

  const root = document.documentElement;
  const metaPixelId = root.dataset.metaPixelId?.trim();
  const ga4Id = root.dataset.ga4Id?.trim();
  const consentKey = 'page_analytics_consent_v1';
  let trackingReady = false;

  const loadMetaPixel = () => {
    if (!metaPixelId || window.fbq) return;
    !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
    n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
    n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
    t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}
    (window,document,'script','https://connect.facebook.net/en_US/fbevents.js');
    window.fbq('init', metaPixelId);
    window.fbq('track', 'PageView');
  };

  const loadGA4 = () => {
    if (!ga4Id || window.gtag) return;
    const script = document.createElement('script');
    script.async = true;
    script.src = `https://www.googletagmanager.com/gtag/js?id=${encodeURIComponent(ga4Id)}`;
    document.head.appendChild(script);
    window.dataLayer = window.dataLayer || [];
    window.gtag = function(){ window.dataLayer.push(arguments); };
    window.gtag('js', new Date());
    window.gtag('config', ga4Id, { anonymize_ip: true });
  };

  const enableTracking = () => {
    if (trackingReady) return;
    loadMetaPixel();
    loadGA4();
    trackingReady = true;
  };

  const trackWhatsApp = (element) => {
    const location = element.closest('header') ? 'header' : element.classList.contains('mobile-cta') ? 'mobile_fixed' : element.closest('.final-cta') ? 'final_cta' : element.closest('.hero') ? 'hero' : 'content';
    if (window.fbq) window.fbq('trackCustom', 'click_whatsapp', { button_location: location });
    if (window.gtag) window.gtag('event', 'click_whatsapp', { button_location: location, link_url: element.href });
  };

  const savedConsent = localStorage.getItem(consentKey);
  const consent = document.querySelector('[data-consent]');
  if (savedConsent === 'accepted') enableTracking();
  else if (!savedConsent && consent) consent.hidden = false;

  document.querySelector('[data-consent-accept]')?.addEventListener('click', () => {
    localStorage.setItem(consentKey, 'accepted');
    consent.hidden = true;
    enableTracking();
  });
  document.querySelector('[data-consent-reject]')?.addEventListener('click', () => {
    localStorage.setItem(consentKey, 'rejected');
    consent.hidden = true;
  });

  document.querySelectorAll('[data-whatsapp]').forEach((link) => {
    link.addEventListener('click', () => trackWhatsApp(link));
  });

  const header = document.querySelector('[data-header]');
  const updateHeader = () => header?.classList.toggle('scrolled', window.scrollY > 20);
  updateHeader();
  window.addEventListener('scroll', updateHeader, { passive: true });

  const toggle = document.querySelector('[data-menu-toggle]');
  const menu = document.querySelector('[data-menu]');
  toggle?.addEventListener('click', () => {
    const open = toggle.getAttribute('aria-expanded') === 'true';
    toggle.setAttribute('aria-expanded', String(!open));
    menu?.classList.toggle('open', !open);
  });
  menu?.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => {
    toggle?.setAttribute('aria-expanded', 'false');
    menu.classList.remove('open');
  }));

  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if ('IntersectionObserver' in window && !reducedMotion) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    document.querySelectorAll('.reveal').forEach((element) => observer.observe(element));
  } else {
    document.querySelectorAll('.reveal').forEach((element) => element.classList.add('is-visible'));
  }

  const year = document.querySelector('[data-year]');
  if (year) year.textContent = new Date().getFullYear();
})();
